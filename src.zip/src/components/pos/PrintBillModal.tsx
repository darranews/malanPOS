"use client";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { formatMoney } from "@/lib/utils/formatMoney";
import { useRef } from "react";
import QRCode from "qrcode.react";

export function PrintBillModal({ open, onOpenChange, order }: any) {
  const printRef = useRef<HTMLDivElement>(null);

  const orderLink = typeof window !== "undefined" 
    ? `${window.location.origin}/order/${order?.id}`
    : "";

  const handlePrint = () => {
    if (printRef.current) {
      const printContents = printRef.current.innerHTML;
      const printWindow = window.open("", "_blank", "width=400,height=600");
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Hóa đơn</title>
              <style>
                body { font-family: sans-serif; padding: 16px; }
                h2 { text-align: center; margin-bottom: 8px; }
                table { width: 100%; border-collapse: collapse; margin-top: 8px; }
                th, td { padding: 4px; text-align: left; }
                tfoot td { font-weight: bold; }
                .total { font-size: 1.1rem; }
                .center { text-align: center; }
                img { display: block; margin: 0 auto 8px; max-width: 60px; }
              </style>
            </head>
            <body>${printContents}</body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  if (!order) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Hóa đơn #{order.id}</DialogTitle>
        </DialogHeader>

        {/* Bill Preview */}
        <div ref={printRef} className="bg-white p-4 rounded border">
          {/* Logo */}
          <img
            src="/images/logo.png"
            alt="MalanPOS Logo"
            className="w-16 mx-auto mb-2"
          />

          <h2 className="text-lg font-bold text-center">MalanPOS</h2>
          <p className="text-sm text-gray-500 text-center">
            Ngày: {new Date().toLocaleString()}
          </p>
          <p className="text-sm text-gray-500 text-center">
            NV: {order.staffName || "Không xác định"}
          </p>

          <table>
            <thead>
              <tr>
                <th>Sản phẩm</th>
                <th>SL</th>
                <th className="text-right">Giá</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item: any) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>{item.quantity}</td>
                  <td className="text-right">
                    {formatMoney(item.price * item.quantity)}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={2}>Tổng</td>
                <td className="text-right total">
                  {formatMoney(order.total)}
                </td>
              </tr>
            </tfoot>
          </table>

          {/* QR Code */}
          <div className="center mt-4">
            <QRCode value={orderLink} size={80} />
            <p className="text-xs mt-1">Quét để xem hóa đơn online</p>
          </div>

          <p className="center text-sm mt-4">Cảm ơn quý khách!</p>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Đóng
          </Button>
          <Button onClick={handlePrint}>In hóa đơn</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
