"use client";

import ProductItem from "@/components/product/ProductItem";
import { Product } from "@/lib/types/product";

interface ProductListProps {
  products: Product[];
  onAddToOrder: (product: Product) => void;
}

export default function ProductList({ products, onAddToOrder }: ProductListProps) {
  if (!products || products.length === 0) {
    return (
      <div className="text-center text-gray-500 py-4">
        No products available.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
      {products.map((product) => (
        <ProductItem
          key={product.id}
          product={product}
          onClick={() => onAddToOrder(product)}
        />
      ))}
    </div>
  );
}
