"use client";

import { useState } from "react";
import { CategoryTabs } from "@/components/pos/CategoryTabs";
import { ProductList } from "@/components/pos/ProductList";
import { OrderPanel } from "@/components/pos/OrderPanel";
import { FloatingActionBar } from "@/components/shared/FloatingActionBar";
import { ProductSearch } from "@/components/shared/ProductSearch"; // ✅ Sửa lại đúng thư mục mới
import { PrintBillModal } from "@/components/pos/PrintBillModal";
import { useProducts } from "@/lib/hooks/useProducts";
import { useOrders } from "@/lib/hooks/useOrders";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";

export default function POSPage() {
  const { products, categories, loading: loadingProducts } = useProducts();
  const {
    currentOrder,
    addItem,
    removeItem,
    clearOrder,
    checkoutOrder,
    loading: loadingOrders,
  } = useOrders();

  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  const handleCheckout = async () => {
    const success = await checkoutOrder();
    if (success) {
      setIsPrintModalOpen(true);
    }
  };

  return (
    <div className="flex flex-col h-full p-2 md:p-4">
      {/* Desktop Layout */}
      <div className="hidden md:grid md:grid-cols-3 gap-4 h-full">
        {/* Left side: Products */}
        <Card className="col-span-2 flex flex-col">
          <ProductSearch />
          <CategoryTabs
            categories={categories}
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />
          <div className="flex-1 overflow-auto">
            <ProductList
              products={products}
              category={selectedCategory}
              onAdd={addItem}
              loading={loadingProducts}
            />
          </div>
        </Card>

        {/* Right side: Order */}
        <Card className="flex flex-col">
          <OrderPanel
            order={currentOrder}
            onRemove={removeItem}
            onClear={clearOrder}
          />
          <div className="p-2 border-t">
            <Button
              className="w-full"
              onClick={handleCheckout}
              disabled={!currentOrder.items.length || loadingOrders}
            >
              Thanh toán
            </Button>
          </div>
        </Card>
      </div>

      {/* Mobile Layout */}
      <div className="md:hidden flex flex-col flex-1">
        <Tabs defaultValue="products" className="flex flex-col flex-1">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="products">Sản phẩm</TabsTrigger>
            <TabsTrigger value="order">Giỏ hàng</TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="flex-1 overflow-auto">
            <ProductSearch />
            <CategoryTabs
              categories={categories}
              selected={selectedCategory}
              onSelect={setSelectedCategory}
            />
            <ProductList
              products={products}
              category={selectedCategory}
              onAdd={addItem}
              loading={loadingProducts}
            />
          </TabsContent>

          <TabsContent value="order" className="flex-1 overflow-auto">
            <OrderPanel
              order={currentOrder}
              onRemove={removeItem}
              onClear={clearOrder}
            />
            <div className="p-2 border-t">
              <Button
                className="w-full"
                onClick={handleCheckout}
                disabled={!currentOrder.items.length || loadingOrders}
              >
                Thanh toán
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating Action Bar */}
      <FloatingActionBar />

      {/* Print Bill Modal */}
      <PrintBillModal
        open={isPrintModalOpen}
        onOpenChange={setIsPrintModalOpen}
        order={currentOrder}
      />
    </div>
  );
}
